package me.witherequipment;

import java.util.*;
import org.bukkit.*;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.*;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.inventory.*;
import org.bukkit.potion.*;
import org.bukkit.scheduler.BukkitRunnable;
import me.witherprogress.*;

/** Real PvE shockwave, charge handling and equipment diagnostics. */
public final class AftershockFix {
 static final List<EquipmentSlot> SLOTS=List.of(EquipmentSlot.HEAD,EquipmentSlot.CHEST,EquipmentSlot.LEGS,EquipmentSlot.FEET);
 static int threshold(int configured){return Math.clamp(configured,1,1000);}
 static boolean charge(Map<String,Integer> counters,String key,int required,boolean ready){
  int count=Math.min(threshold(required),Math.max(0,counters.getOrDefault(key,0))+1);counters.put(key,count);return ready&&count>=threshold(required);
 }
 static boolean eligible(Entity entity){
  if(!(entity instanceof Mob mob)||!mob.isValid()||mob.isDead()||mob.isInvulnerable())return false;
  if(mob instanceof Tameable pet&&pet.isTamed())return false;
  for(NamespacedKey key:mob.getPersistentDataContainer().getKeys())if(key.getNamespace().equals("withernpcs")||key.getNamespace().equals("withershops"))return false;
  return true;
 }
 static int damageTargets(Collection<? extends Entity> targets,Player player,Location center,double radius,double damage){
  int hit=0;
  for(Entity entity:targets){
   if(!eligible(entity)||entity.getWorld()!=center.getWorld()||entity.getLocation().distanceSquared(center)>radius*radius)continue;
   Mob mob=(Mob)entity;int previousTicks=mob.getNoDamageTicks();double previousDamage=mob.getLastDamage();
   // The triggering hit must not absorb this separate ability's damage.
   mob.setNoDamageTicks(0);
   try{mob.damage(damage,player);hit++;}
   finally{if(mob.isValid()&&!mob.isDead()){mob.setNoDamageTicks(Math.max(previousTicks,mob.getNoDamageTicks()));mob.setLastDamage(Math.max(previousDamage,mob.getLastDamage()));}}
  }
  return hit;
 }
 public static void hit(Equipment equipment,EntityDamageByEntityEvent event){
  if(event.isCancelled()||event.getFinalDamage()<=0)return;
  Player attacker=Equipment.attacker(event.getDamager());
  if(attacker!=null&&equipment.aftershock.contains(attacker.getUniqueId()))return;
  if(event.getEntity() instanceof Player victim){
   equipment.lastDamage.put(victim.getUniqueId(),System.currentTimeMillis());
   LivingEntity aggressor=attacker!=null?attacker:(event.getDamager() instanceof LivingEntity l?l:null);
   if(aggressor!=null)for(String path:equipment.effects(victim))if(equipment.io.y.getString(path+"type","").equals("COLD_GUARD")&&equipment.scope(path,attacker!=null)&&equipment.proc(victim,path))aggressor.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS,equipment.io.y.getInt(path+"duration",60),Math.max(0,(int)equipment.io.y.getDouble(path+"value",1)-1)));
  }
  if(attacker==null)return;equipment.lastDamage.put(attacker.getUniqueId(),System.currentTimeMillis());
  if(!eligible(event.getEntity()))return;
  long now=System.currentTimeMillis();
  for(String path:equipment.effects(attacker)){
   if(!equipment.io.y.getString(path+"type","").equals("AFTERSHOCK"))continue;
   String key=attacker.getUniqueId()+":"+path;int required=threshold(equipment.io.y.getInt(path+"hits",10));long readyAt=equipment.ready.getOrDefault(key,0L);
   boolean attempt=charge(equipment.hits,key,required,now>=readyAt);int count=equipment.hits.get(key);
   if(!attempt){attacker.sendActionBar(Ui.text("<green>Aftershock: "+count+"/"+required+(now<readyAt?" <gray>| Cooldown: "+((readyAt-now+999)/1000)+"s":"")));continue;}
   equipment.hits.put(key,0);
   if(!equipment.proc(attacker,path)){attacker.sendActionBar(Ui.text("<gray>Aftershock: activation chance missed"));continue;}
   Location center=event.getEntity().getLocation().clone().add(0,0.15,0);double radius=Math.clamp(equipment.io.y.getDouble(path+"radius",3),1,10),damage=Math.clamp(equipment.io.y.getDouble(path+"value",2),0,100);
   attacker.sendActionBar(Ui.text("<green><bold>AFTERSHOCK!</bold> <gray>"+damage+" damage · "+radius+" blocks"));
   Bukkit.getScheduler().runTask(equipment,()->{
    if(!attacker.isOnline()||center.getWorld()==null)return;
    equipment.aftershock.add(attacker.getUniqueId());
    try{damageTargets(center.getWorld().getNearbyEntities(center,radius,radius,radius),attacker,center,radius,damage);}
    finally{equipment.aftershock.remove(attacker.getUniqueId());}
    center.getWorld().playSound(center,Sound.ENTITY_GENERIC_EXPLODE,0.65f,1.6f);
    center.getWorld().spawnParticle(Particle.EXPLOSION,center,1,0,0,0,0);
    new BukkitRunnable(){int frame;
     public void run(){if(!attacker.isOnline()||++frame>10){cancel();return;}double r=radius*frame/10.0;
      for(int i=0;i<32;i++){double angle=Math.PI*2*i/32;Location point=center.clone().add(Math.cos(angle)*r,0.12,Math.sin(angle)*r);center.getWorld().spawnParticle(Particle.ELECTRIC_SPARK,point,1,0.03,0.03,0.03,0);}
     }
    }.runTaskTimer(equipment,0,1);
   });
  }
 }
 static int matching(Equipment e,Player player,String set){int count=0;for(EquipmentSlot slot:SLOTS){String id=e.io.y.getString("sets."+set+".pieces."+slot.name(),"");if(!id.isEmpty()&&id.equals(e.core.registered(player.getInventory().getItem(slot))))count++;}return count;}
 public static void view(Equipment e,Player p){
  Ui.Menu menu=new Ui.Menu(p,"Your equipment effects",false);Set<String> active=new HashSet<>(e.active(p));int slot=0;
  for(String set:Progress.keys(e.io,"sets")){if(slot>=18)break;String root="sets."+set+".";int count=matching(e,p,set),required=e.io.y.getInt(root+"required",4);boolean enabled=e.io.y.getBoolean(root+"enabled");
   if(!enabled&&count==0)continue;
   menu.button(slot++,active.contains(set)?Material.DIAMOND_CHESTPLATE:Material.LEATHER_CHESTPLATE,e.io.y.getString(root+"name",set),click->{},enabled?(active.contains(set)?"<green>Active":"<yellow>Inactive: wear the matching registered armor"):"<red>Disabled in set settings","Matching armor pieces: "+count+" / "+required);
  }
  slot=18;for(String path:e.effects(p)){if(slot>=45)break;String type=e.io.y.getString(path+"type","");String key=p.getUniqueId()+":"+path;long cooldown=Math.max(0,(e.ready.getOrDefault(key,0L)-System.currentTimeMillis()+999)/1000);
   List<String> lore=new ArrayList<>();lore.add("Chance: "+e.io.y.getDouble(path+"chance",100)+"%");lore.add(cooldown==0?"<green>Ready":"Cooldown: "+cooldown+"s");
   if(type.equals("AFTERSHOCK")){lore.add("Charge: "+e.hits.getOrDefault(key,0)+" / "+threshold(e.io.y.getInt(path+"hits",10)));lore.add("Damage: "+e.io.y.getDouble(path+"value",2));lore.add("Radius: "+e.io.y.getDouble(path+"radius",3)+" blocks");lore.add("Works on normal PvE mobs, area mobs and bosses.");lore.add("Players, protected NPCs and tamed pets are excluded.");}
   menu.button(slot++,type.equals("AFTERSHOCK")?Material.TNT:Material.BLAZE_POWDER,type,click->{},lore.toArray(String[]::new));
  }
  if(slot==18)menu.button(22,Material.BARRIER,"No active effects",click->{},"Check enabled status, matching registered items and required pieces.");
  menu.button(49,Material.SPYGLASS,"Refresh equipment status",click->view(e,p));
  if(p.isOp())menu.button(53,Material.COMMAND_BLOCK,"Operator settings",click->e.admin(p));menu.open(p);
 }
 public static void effect(Equipment e,Player p,String set,String id,String type){
  String path=(set.startsWith("tool:")?"tools."+set.substring(5):"sets."+set)+".effects."+id+".";
  Forms.show(e,p,"Aftershock settings","A visible PvE shockwave. Value is extra damage (2 = one heart before defenses). Charge is retained during cooldown. Players, protected NPCs, tamed pets and blocks are unaffected.",List.of(Forms.text("value","Extra damage (0–100)",Double.toString(e.io.y.getDouble(path+"value",2)),8),Forms.text("hits","Hits required (1–1000)",Integer.toString(e.io.y.getInt(path+"hits",10)),5),Forms.text("chance","Activation chance (%)",Double.toString(e.io.y.getDouble(path+"chance",100)),8),Forms.text("cooldown","Cooldown (seconds)",Double.toString(e.io.y.getDouble(path+"cooldown",10)),10),Forms.text("radius","Shockwave radius (1–10 blocks)",Double.toString(e.io.y.getDouble(path+"radius",3)),5),Forms.choice("remove","Delete effect","no","yes","no")),v->{
   if(v.get("remove").equals("yes")){e.io.y.set(path,null);e.io.save();e.editAny(p,set);return;}
   double damage=Double.parseDouble(v.get("value")),chance=Double.parseDouble(v.get("chance")),cooldown=Double.parseDouble(v.get("cooldown")),radius=Double.parseDouble(v.get("radius"));int hits=Integer.parseInt(v.get("hits"));
   if(!Double.isFinite(damage)||!Double.isFinite(chance)||!Double.isFinite(cooldown)||!Double.isFinite(radius)||damage<0||damage>100||chance<0||chance>100||cooldown<0||cooldown>86400||radius<1||radius>10||hits<1||hits>1000)throw new IllegalArgumentException("Damage/chance: 0–100; cooldown: 0–86400s; radius: 1–10; hits: 1–1000.");
   e.io.y.set(path+"type","AFTERSHOCK");e.io.y.set(path+"scope","PVE");e.io.y.set(path+"value",damage);e.io.y.set(path+"hits",hits);e.io.y.set(path+"chance",chance);e.io.y.set(path+"cooldown",cooldown);e.io.y.set(path+"radius",radius);e.io.save();e.editAny(p,set);
  },()->e.editAny(p,set));
 }
 public static boolean diagnose(Equipment e,CommandSender sender,String[] args){
  if(args.length==0||!args[0].equalsIgnoreCase("diagnose"))return false;
  if(!sender.isOp()){sender.sendMessage("Only operators can inspect equipment.");return true;}
  Player p=args.length>1?Bukkit.getPlayerExact(args[1]):sender instanceof Player pl?pl:null;
  if(p==null){sender.sendMessage("Use /equipment diagnose <online-player>.");return true;}
  sender.sendMessage("Equipment diagnostic for "+p.getName());
  for(EquipmentSlot s:SLOTS){var item=p.getInventory().getItem(s);sender.sendMessage(s+": "+(item==null?"empty":item.getType())+" | registered ID: "+e.core.registered(item));}
  for(String set:Progress.keys(e.io,"sets"))if(e.io.y.getBoolean("sets."+set+".enabled"))sender.sendMessage("Set "+set+": "+matching(e,p,set)+"/"+e.io.y.getInt("sets."+set+".required",4)+" matching pieces");
  List<String> active=e.effects(p);sender.sendMessage("Active effects: "+active.size());for(String path:active)if(e.io.y.getString(path+"type","").equals("AFTERSHOCK")){String key=p.getUniqueId()+":"+path;sender.sendMessage("Aftershock: "+e.hits.getOrDefault(key,0)+"/"+e.io.y.getInt(path+"hits",10)+" hits; chance "+e.io.y.getDouble(path+"chance",100)+"%; damage "+e.io.y.getDouble(path+"value",2)+"; cooldown "+Math.max(0,(e.ready.getOrDefault(key,0L)-System.currentTimeMillis()+999)/1000)+"s");}
  return true;
 }
}

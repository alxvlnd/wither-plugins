package me.witherequipment;
import java.lang.reflect.*;import java.util.*;import org.bukkit.*;import org.bukkit.entity.*;import org.bukkit.persistence.PersistentDataContainer;
public class AftershockChecks{
 static void ok(boolean condition,String description){if(!condition)throw new AssertionError(description);}
 static Object defaultValue(Class<?>type){if(!type.isPrimitive())return null;if(type==boolean.class)return false;if(type==double.class)return 0d;if(type==float.class)return 0f;if(type==long.class)return 0L;return 0;}
 static class MockMob implements InvocationHandler{
  final World world;final double x;final Set<NamespacedKey>keys;final boolean invulnerable,tamed;int ticks=20,damageCalls;double last=7,received;boolean damageSawZero;
  MockMob(World w,double x,Set<NamespacedKey>keys,boolean inv,boolean tamed){world=w;this.x=x;this.keys=keys;invulnerable=inv;this.tamed=tamed;}
  public Object invoke(Object p,Method m,Object[]a){return switch(m.getName()){
   case "isValid"->true;case "isDead"->false;case "isInvulnerable"->invulnerable;case "isTamed"->tamed;
   case "getWorld"->world;case "getLocation"->new Location(world,x,0,0);case "getNoDamageTicks"->ticks;case "setNoDamageTicks"->{ticks=(Integer)a[0];yield null;}
   case "getLastDamage"->last;case "setLastDamage"->{last=(Double)a[0];yield null;}
   case "damage"->{damageCalls++;received+=(Double)a[0];damageSawZero=ticks==0;ticks=20;last=(Double)a[0];yield null;}
   case "getPersistentDataContainer"->Proxy.newProxyInstance(PersistentDataContainer.class.getClassLoader(),new Class[]{PersistentDataContainer.class},(o,n,args)->n.getName().equals("getKeys")?keys:defaultValue(n.getReturnType()));
   case "equals"->p==a[0];case "hashCode"->System.identityHashCode(p);case "toString"->"MockMob";default->defaultValue(m.getReturnType());};}
  <T>T proxy(Class<T>type){return type.cast(Proxy.newProxyInstance(type.getClassLoader(),new Class[]{type},this));}
 }
 public static void main(String[]args)throws Exception{
  var handler=Equipment.class.getDeclaredMethod("hit",org.bukkit.event.entity.EntityDamageByEntityEvent.class).getAnnotation(org.bukkit.event.EventHandler.class);ok(handler!=null&&handler.ignoreCancelled()&&handler.priority()==org.bukkit.event.EventPriority.MONITOR,"event handler registration contract");
  Map<String,Integer>hits=new HashMap<>();ok(!AftershockFix.charge(hits,"a",2,true),"first hit must charge");ok(AftershockFix.charge(hits,"a",2,true),"second hit must trigger");
  hits.clear();ok(!AftershockFix.charge(hits,"a",2,false),"cooldown must not trigger");ok(!AftershockFix.charge(hits,"a",2,false)&&hits.get("a")==2,"cooldown must retain full charge");ok(!AftershockFix.charge(hits,"a",2,false)&&hits.get("a")==2,"charge must not overflow or reset during cooldown");ok(AftershockFix.charge(hits,"a",2,true),"first hit after cooldown must use retained charge");
  ok(!AftershockFix.charge(hits,"other",2,true)&&hits.get("a")==2,"independent player/effect counters");
  World world=(World)Proxy.newProxyInstance(World.class.getClassLoader(),new Class[]{World.class},(o,m,a)->m.getName().equals("equals")?o==a[0]:m.getName().equals("hashCode")?System.identityHashCode(o):defaultValue(m.getReturnType()));
  Player player=(Player)Proxy.newProxyInstance(Player.class.getClassLoader(),new Class[]{Player.class},(o,m,a)->defaultValue(m.getReturnType()));
  MockMob normal=new MockMob(world,1,Set.of(),false,false),npc=new MockMob(world,1,Set.of(new NamespacedKey("withernpcs","npc_id")),false,false),shop=new MockMob(world,1,Set.of(new NamespacedKey("withershops","shop_id")),false,false),far=new MockMob(world,4,Set.of(),false,false),inv=new MockMob(world,1,Set.of(),true,false),pet=new MockMob(world,1,Set.of(),false,true);
  var golem=normal.proxy(IronGolem.class);ok(AftershockFix.eligible(golem),"unmarked iron golems must be eligible");ok(!AftershockFix.eligible(player),"players must be excluded");
  int count=AftershockFix.damageTargets(List.of(golem,npc.proxy(Mob.class),shop.proxy(Mob.class),far.proxy(Mob.class),inv.proxy(Mob.class),pet.proxy(Wolf.class),player),player,new Location(world,0,0,0),3,2);
  ok(count==1&&normal.damageCalls==1&&normal.received==2,"wave must hit eligible mob once");ok(normal.damageSawZero&&normal.ticks==20&&normal.last==7,"extra damage bypasses triggering hurt window while restoring protection");ok(npc.damageCalls==0&&shop.damageCalls==0&&far.damageCalls==0&&inv.damageCalls==0&&pet.damageCalls==0,"NPCs, protected mobs, pets and out-of-radius targets remain untouched");
  System.out.println("PASS 13 Aftershock regressions: charge retention, cooldown, separate counters, ordinary golems, player/NPC/pet exclusions, range and hurt-window handling. Local mocks only; no in-game tests.");
 }
}

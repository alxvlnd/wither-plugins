WitherEquipment 1.0.1 – Aftershock fix

Fixes:
- Expanding shockwave ring, explosion sound and activation indicator. No block damage.
- Ordinary PvE mobs (including unmarked iron golems), area mobs and bosses are eligible.
- Players, protected NPCs, invulnerable mobs and tamed pets are excluded.
- Charge is retained during cooldown; the next eligible hit can trigger a fully charged effect.
- Extra damage is applied independently of the triggering hit without removing normal hurt protection afterward.
- /equipment displays matching armor counts, effect charge and cooldown.
- Aftershock settings explain damage and offer a configurable radius.
- Operators: equipment diagnose <online-player> for read-only activation diagnostics.

Existing sets, items, bindings and effect values are preserved.
Verified locally: 13 regression checks and 356 plugin classes/integration fields. No in-game tests performed.

package me.witherutils;
import io.papermc.paper.dialog.*;import io.papermc.paper.registry.data.dialog.*;import io.papermc.paper.registry.data.dialog.action.*;import io.papermc.paper.registry.data.dialog.body.*;import io.papermc.paper.registry.data.dialog.input.*;import io.papermc.paper.registry.data.dialog.type.*;
import java.time.Duration;import java.util.*;import java.util.concurrent.ConcurrentHashMap;import java.util.function.Consumer;import net.kyori.adventure.text.Component;import net.kyori.adventure.text.event.ClickCallback;import org.bukkit.Bukkit;import org.bukkit.entity.Player;import org.bukkit.plugin.java.JavaPlugin;
public final class Forms {
 private static final Map<UUID,UUID> SESSIONS=new ConcurrentHashMap<>();
 public record Field(String key,String label,String value,int limit,List<String> options,boolean multiline){public Field{Support.check(key.matches("[a-z][a-z0-9_]*"),"Invalid input field.");options=List.copyOf(options);value=Objects.requireNonNullElse(value,"");}public Field value(String v){return new Field(key,label,v,limit,options,multiline);}}
 public static Field text(String key,String label,String value,int limit){return new Field(key,label,value,limit,List.of(),false);}
 public static Field multiline(String key,String label,String value,int limit){return new Field(key,label,value,limit,List.of(),true);}
 public static Field choice(String key,String label,String value,String...options){return new Field(key,label,value,0,List.of(options),false);}
 public static void invalidate(Player p){SESSIONS.remove(p.getUniqueId());}
 public static void show(JavaPlugin plugin,Player player,String title,String description,List<Field> fields,Consumer<Map<String,String>> save,Runnable back){show(plugin,player,title,description,fields,save,back,"Save",true);}
 public static void confirm(JavaPlugin plugin,Player p,String title,String description,Runnable action,Runnable back){show(plugin,p,title,description,List.of(),values->action.run(),back,"Confirm",true);}
 public static void notice(JavaPlugin plugin,Player p,String title,String description){show(plugin,p,title,description,List.of(),values->{},()->{},"Continue",false);}
 private static void show(JavaPlugin plugin,Player player,String title,String description,List<Field> fields,Consumer<Map<String,String>> save,Runnable back,String saveLabel,boolean admin){
  if(!plugin.isEnabled()||!player.isOnline()||(admin&&!player.isOp()))return;UUID token=UUID.randomUUID();SESSIONS.put(player.getUniqueId(),token);
  List<DialogInput> inputs=fields.stream().map(f->{String key="wither_form_"+f.key();if(!f.options().isEmpty())return (DialogInput)DialogInput.singleOption(key,300,f.options().stream().map(o->SingleOptionDialogInput.OptionEntry.create(o,Component.text(o),o.equals(f.value()))).toList(),Component.text(f.label()),true);var input=DialogInput.text(key,Component.text(f.label())).initial(f.value()).maxLength(f.limit()).width(300);if(f.multiline())input.multiline(TextDialogInput.MultilineOptions.create(24,130));return (DialogInput)input.build();}).toList();
  java.util.function.Function<Boolean,ActionButton> button=accept->ActionButton.create(Component.text(accept?saveLabel:"Cancel / Back"),null,145,DialogAction.customClick((response,audience)->{
   if(!(audience instanceof Player actor)||!actor.getUniqueId().equals(player.getUniqueId()))return;Map<String,String> values=new LinkedHashMap<>();for(Field f:fields)values.put(f.key(),Objects.requireNonNullElse(response.getText("wither_form_"+f.key()),""));
   Bukkit.getScheduler().runTask(plugin,()->{if(!plugin.isEnabled()||!actor.isOnline()||(admin&&!actor.isOp())||!SESSIONS.remove(actor.getUniqueId(),token))return;if(!accept){back.run();return;}try{save.accept(Map.copyOf(values));}catch(Exception e){List<Field> retry=fields.stream().map(f->f.value(values.get(f.key()))).toList();show(plugin,actor,title,"Please correct: "+Objects.requireNonNullElse(e.getMessage(),"Invalid input")+"\n\n"+description,retry,save,back,saveLabel,admin);}});
  },ClickCallback.Options.builder().uses(1).lifetime(Duration.ofMinutes(5)).build()));
  DialogBase base=DialogBase.builder(Component.text(title)).canCloseWithEscape(true).pause(false).afterAction(DialogBase.DialogAfterAction.CLOSE).body(List.of(DialogBody.plainMessage(Support.text(description.substring(0,Math.min(description.length(),8192))),300))).inputs(inputs).build();
  player.showDialog(Dialog.create(factory->factory.empty().base(base).type(DialogType.multiAction(List.of(button.apply(true)),button.apply(false),1))));
 }
 private Forms(){}
}


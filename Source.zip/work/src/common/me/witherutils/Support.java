package me.witherutils;
import java.io.*;import java.nio.file.*;import java.util.*;import java.util.function.*;
import org.bukkit.*;import org.bukkit.command.*;import org.bukkit.configuration.file.YamlConfiguration;import org.bukkit.entity.*;import org.bukkit.event.*;import org.bukkit.event.inventory.*;import org.bukkit.event.player.*;import org.bukkit.inventory.*;import org.bukkit.inventory.meta.*;import org.bukkit.plugin.java.JavaPlugin;
import net.kyori.adventure.text.*;import net.kyori.adventure.text.minimessage.MiniMessage;
public class Support implements Listener {
 public final JavaPlugin plugin; public final YamlConfiguration data; private final File file;
 public static final MiniMessage MM=MiniMessage.miniMessage();
 public Support(JavaPlugin p,String filename){plugin=p;file=new File(p.getDataFolder(),filename);data=new YamlConfiguration();try{if(file.exists())data.load(file);}catch(Exception e){throw new IllegalStateException("Cannot read "+file+"; preserved",e);} Bukkit.getPluginManager().registerEvents(this,p);}
 public void save(){try{Files.createDirectories(file.toPath().getParent());Path temp=file.toPath().resolveSibling(file.getName()+".tmp");Files.writeString(temp,data.saveToString());try{Files.move(temp,file.toPath(),StandardCopyOption.ATOMIC_MOVE,StandardCopyOption.REPLACE_EXISTING);}catch(AtomicMoveNotSupportedException ex){Files.move(temp,file.toPath(),StandardCopyOption.REPLACE_EXISTING);}}catch(IOException e){throw new IllegalStateException("Cannot save "+file,e);}}
 public static Component text(String s){try{return MM.deserialize(s);}catch(Exception e){return Component.text(s);}}
 public static String id(String s){if(!s.matches("[a-z0-9_-]{1,48}"))throw new IllegalArgumentException("ID: a-z, 0-9, _ and -, maximum 48 characters.");return s;}
 public static void check(boolean b,String m){if(!b)throw new IllegalArgumentException(m);}
 public static String rank(UUID id){var p=Bukkit.getPluginManager().getPlugin("WitherRanks");if(p==null||!p.isEnabled())return "";try{return (String)p.getClass().getMethod("getPlayerRank",UUID.class).invoke(p,id);}catch(Exception e){return "";}}
 @SuppressWarnings("unchecked") public static boolean rankAllows(Player p,String required){if(p.isOp()||required.isBlank())return true;var r=Bukkit.getPluginManager().getPlugin("WitherRanks");if(r==null||!r.isEnabled())return false;try{Map<String,Integer> priorities=(Map<String,Integer>)r.getClass().getMethod("getRankPriorities").invoke(r);String active=rank(p.getUniqueId());return priorities.containsKey(required)&&priorities.containsKey(active)&&priorities.get(active)>=priorities.get(required);}catch(Exception e){return false;}}
 public static ItemStack icon(Material m,String name,String... lore){ItemStack i=new ItemStack(m);var meta=i.getItemMeta();meta.displayName(text("<white>"+name));meta.lore(Arrays.stream(lore).map(Support::text).toList());i.setItemMeta(meta);return i;}
 public static String encode(ItemStack i){return Base64.getEncoder().encodeToString(i.serializeAsBytes());} public static ItemStack decode(String s){return ItemStack.deserializeBytes(Base64.getDecoder().decode(s));}
 public static Player player(CommandSender s){check(s instanceof Player,"Use this command in game.");return (Player)s;}
 public static void admin(CommandSender s){check(!(s instanceof Player)||s.isOp(),"Only operators can edit these settings.");}
 public static String tail(String[] a,int start){return String.join(" ",Arrays.copyOfRange(a,start,a.length));}
 public static class Menu implements InventoryHolder { public Inventory inv; final Map<Integer,Consumer<InventoryClickEvent>> clicks=new HashMap<>(); public Menu(String title){inv=Bukkit.createInventory(this,54,text(title));} public Inventory getInventory(){return inv;} public Menu at(int slot,ItemStack item,Consumer<InventoryClickEvent> click){inv.setItem(slot,item);clicks.put(slot,click);return this;} public void open(Player p){Forms.invalidate(p);p.openInventory(inv);} }
 @EventHandler(priority=EventPriority.HIGHEST) public void click(InventoryClickEvent e){if(!(e.getView().getTopInventory().getHolder() instanceof Menu m))return;e.setCancelled(true);if(!e.getWhoClicked().isOp())return;if(e.getRawSlot()<0||e.getRawSlot()>=54)return;var c=m.clicks.get(e.getRawSlot());if(c!=null)try{c.accept(e);}catch(Exception ex){e.getWhoClicked().sendMessage(text("<red>"+ex.getMessage()));}}
 @EventHandler(priority=EventPriority.HIGHEST) public void drag(InventoryDragEvent e){if(e.getView().getTopInventory().getHolder() instanceof Menu)e.setCancelled(true);}
 public static String playerText(String s,Player p){return s.replace("{player}",p.getName()).replace("{uuid}",p.getUniqueId().toString());}
}

package me.withertab;
import me.witherutils.*;import org.bukkit.*;import org.bukkit.entity.Player;import java.util.*;
final class TabWindows {
 final WitherTab owner;TabWindows(WitherTab p){owner=p;}
 void open(Player p){Support.Menu m=new Support.Menu("TAB settings");m.at(10,Support.icon(Material.LIME_DYE,"Enabled"),e->toggle(p,"enabled","TAB enabled"));m.at(12,Support.icon(Material.WRITABLE_BOOK,"Header"),e->text(p,"header","TAB header"));m.at(14,Support.icon(Material.PAPER,"Footer"),e->text(p,"footer","TAB footer"));m.at(16,Support.icon(Material.CLOCK,"Ping beside player names"),e->toggle(p,"ping-in-name","Show ping beside names"));m.at(31,Support.icon(Material.NAME_TAG,"Rank display information"),e->Forms.notice(owner,p,"Rank display","TAB uses the prefixes and gradients configured in /rank and sorts by rank priority. Text placeholders: {online}, {max}, {ping}, {player}, {rank}."));m.open(p);}
 void toggle(Player p,String key,String title){Forms.show(owner,p,title,"Choose the desired value.",List.of(Forms.choice("value",title,owner.getConfig().getBoolean(key,true)?"on":"off","on","off")),v->{owner.getConfig().set(key,v.get("value").equals("on"));owner.saveConfig();owner.update();open(p);},()->open(p));}
 void text(Player p,String key,String title){Forms.show(owner,p,title,"One display line per line. Supports MiniMessage gradients and placeholders.",List.of(Forms.multiline("text",title,owner.getConfig().getString(key,""),2048)),v->{owner.getConfig().set(key,v.get("text"));owner.saveConfig();owner.update();open(p);},()->open(p));}
}

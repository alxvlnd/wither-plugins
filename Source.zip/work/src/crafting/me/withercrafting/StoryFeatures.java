package me.withercrafting;
import me.witherutils.Support;import java.util.*;import org.bukkit.*;import org.bukkit.command.*;import org.bukkit.entity.*;import org.bukkit.event.*;import org.bukkit.event.inventory.*;import org.bukkit.event.block.*;import org.bukkit.plugin.java.JavaPlugin;import org.bukkit.inventory.*;
public final class StoryFeatures extends Support implements CommandExecutor {
 final WitherCrafting owner;final CommandExecutor original;
 public static void install(JavaPlugin p){if(p.isEnabled())new StoryFeatures((WitherCrafting)p);}
 StoryFeatures(WitherCrafting p){super(p,"crafting-settings.yml");owner=p;original=p.getCommand("customrecipes").getExecutor();p.getCommand("customrecipes").setExecutor(this);p.getCommand("recipe").setExecutor(this);if(!data.contains("vanilla-crafting")){data.set("vanilla-crafting",true);save();}}
 public boolean onCommand(CommandSender s,Command c,String label,String[] a){try{
  if(c.getName().equals("customrecipes")&&a.length>0&&!Set.of("vanilla","settings").contains(a[0]))return original.onCommand(s,c,label,a);
  if(c.getName().equals("recipe")&&(a.length==0||!Set.of("unlock","revoke").contains(a[0]))){return owner.onCommand(s,owner.getCommand("recipes"),"recipes",a);}
  admin(s);
  if(a.length>0&&Set.of("unlock","revoke").contains(a[0])){check(a.length==2||a.length==3,"/recipe unlock|revoke <recipe-id> [player]");RecipeData r=owner.store.get(a[1]);UUID target=a.length==2?player(s).getUniqueId():target(a[2]);owner.store.unlock(target,r.id(),a[0].equals("unlock"));owner.engine.syncAll();owner.refreshViews();s.sendMessage("Recipe "+a[0]+": "+r.id());return true;}
  if(a.length==2&&a[0].equals("vanilla")){check(Set.of("on","off").contains(a[1]),"/customrecipes vanilla on|off");data.set("vanilla-crafting",a[1].equals("on"));save();s.sendMessage("Vanilla crafting: "+a[1]+". Operators bypass this setting.");return true;}
  if(a.length>0&&Set.of("settings","vanilla").contains(a[0])){Player p=player(s);new Menu("Crafting settings").at(22,icon(Material.CRAFTING_TABLE,"Vanilla crafting: "+(data.getBoolean("vanilla-crafting",true)?"ON":"OFF"),"Click to toggle","Operators always bypass this setting."),e->{admin(p);data.set("vanilla-crafting",!data.getBoolean("vanilla-crafting",true));save();onCommand(p,c,label,new String[]{"settings"});}).open(p);return true;}
  return original.onCommand(s,c,label,a);
 }catch(Exception e){s.sendMessage("Error: "+e.getMessage());return true;}}
 UUID target(String s){try{return UUID.fromString(s);}catch(Exception e){var p=Bukkit.getPlayerExact(s);if(p!=null)return p.getUniqueId();var offline=Bukkit.getOfflinePlayerIfCached(s);check(offline!=null,"Player must have joined before, or use their UUID.");return offline.getUniqueId();}}
 @EventHandler public void open(org.bukkit.event.inventory.InventoryOpenEvent e){if(e.getPlayer() instanceof Player p&&p.isOp()&&e.getInventory().getHolder() instanceof Ui.Menu m&&m.admin&&net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer.plainText().serialize(e.getView().title()).startsWith("Edit recipes -"))m.button(47,Material.CRAFTING_TABLE,"Vanilla crafting settings",right->onCommand(p,owner.getCommand("customrecipes"),"customrecipes",new String[]{"settings"}),"Toggle vanilla crafting; operators bypass the restriction.");}
 boolean vanilla(Recipe r){return r instanceof Keyed k&&k.getKey().getNamespace().equals("minecraft");}
 @EventHandler(priority=EventPriority.HIGHEST) public void prepare(PrepareItemCraftEvent e){if(!data.getBoolean("vanilla-crafting",true)&&!e.getView().getPlayer().isOp()&&(vanilla(e.getRecipe())||e.isRepair()))e.getInventory().setResult(null);}
 @EventHandler(priority=EventPriority.HIGHEST,ignoreCancelled=true) public void craft(CraftItemEvent e){if(!data.getBoolean("vanilla-crafting",true)&&!e.getWhoClicked().isOp()&&vanilla(e.getRecipe())){e.setCancelled(true);e.getInventory().setResult(null);}}
 @EventHandler(priority=EventPriority.HIGHEST,ignoreCancelled=true) public void crafter(CrafterCraftEvent e){if(!data.getBoolean("vanilla-crafting",true)&&vanilla(e.getRecipe()))e.setCancelled(true);}
}

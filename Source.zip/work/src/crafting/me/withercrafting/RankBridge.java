/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.Bukkit
 *  org.bukkit.entity.Player
 *  org.bukkit.plugin.Plugin
 */
package me.withercrafting;

import java.util.Map;
import java.util.TreeMap;
import java.util.UUID;
import me.withercrafting.RankRule;
import me.withercrafting.RecipeAccess;
import me.withercrafting.RecipeData;
import me.withercrafting.RecipeStore;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;

final class RankBridge {
    final RecipeStore store;

    RankBridge(RecipeStore recipeStore) {
        this.store = recipeStore;
    }

    Snapshot snapshot(UUID uUID) {
        Plugin plugin = Bukkit.getPluginManager().getPlugin("WitherRanks");
        if (plugin == null || !plugin.isEnabled()) {
            return new Snapshot(false, "", Map.of());
        }
        try {
            Object object = plugin.getClass().getMethod("getRankPriorities", new Class[0]).invoke((Object)plugin, new Object[0]);
            TreeMap<String, Integer> treeMap = new TreeMap<String, Integer>();
            for (Map.Entry entry : ((Map<String,Integer>)object).entrySet()) {
                treeMap.put((String)entry.getKey(), (Integer)entry.getValue());
            }
            String string = uUID == null ? "" : (String)plugin.getClass().getMethod("getPlayerRank", UUID.class).invoke((Object)plugin, uUID);
            return new Snapshot(true, string, Map.copyOf(treeMap));
        }
        catch (ClassCastException | ReflectiveOperationException exception) {
            return new Snapshot(false, "", Map.of());
        }
    }

    boolean allowed(RecipeData recipeData, Player player) {
        if (player.isOp() || this.store.unlocked(player.getUniqueId(), recipeData.id())) {
            return true;
        }
        if (recipeData.rank().isEmpty()) {
            return !recipeData.personal();
        }
        Snapshot snapshot = this.snapshot(player.getUniqueId());
        return RecipeAccess.allowed(true, RankRule.allows(recipeData.rank(), recipeData.mode(), snapshot.active(), snapshot.priorities(), snapshot.available()), recipeData.personal(), false);
    }

    String requirement(RecipeData recipeData) {
        return recipeData.rank().isEmpty() ? (recipeData.personal() ? "Personal recipe unlock" : "Everyone") : recipeData.rank() + (recipeData.mode().equals("minimum") ? " or equal/higher priority" : " only") + " OR personal unlock";
    }

    record Snapshot(boolean available, String active, Map<String, Integer> priorities) {
    }
}



from pathlib import Path
import urllib.request, xml.etree.ElementTree as ET, concurrent.futures
p=Path('work/lib'); p.mkdir(exist_ok=True)
base='https://repo.papermc.io/repository/maven-public/'
ns={'m':'http://maven.apache.org/POM/4.0.0'}
root=ET.parse('work/paper.pom').getroot()
deps=[('io.papermc.paper','paper-api','26.3.build.211-stable')]
for d in root.findall('m:dependencies/m:dependency',ns):
 g=d.findtext('m:groupId',namespaces=ns); a=d.findtext('m:artifactId',namespaces=ns); v=d.findtext('m:version',namespaces=ns) or '5.2.0'
 if d.findtext('m:scope',namespaces=ns)=='compile': deps.append((g,a,v))
deps += [('net.kyori','examination-api','1.3.0'),('net.kyori','examination-string','1.3.0'),('org.jetbrains','annotations','26.0.2')]
def fetch(t):
 g,a,v=t; dest=p/f'{a}-{v}.jar'
 if not dest.exists(): urllib.request.urlretrieve(base+g.replace('.','/')+'/'+a+'/'+v+'/'+dest.name,dest)
 return dest.name
with concurrent.futures.ThreadPoolExecutor(max_workers=8) as pool:
 for x in pool.map(fetch,deps): print(x)

if not (p/'asm.jar').exists(): urllib.request.urlretrieve('https://repo.maven.apache.org/maven2/org/ow2/asm/asm/9.8/asm-9.8.jar', p/'asm.jar')

import pathlib,subprocess,zipfile,re,json,hashlib,shutil
ROOT=pathlib.Path(__file__).resolve().parent.parent
JAVA='C:/Program Files/Java/jdk-25.0.3/bin/java.exe'; JAVAC=JAVA.replace('java.exe','javac.exe')
subprocess.run([JAVAC,'-encoding','UTF-8','-cp',str(ROOT/'work/lib/asm.jar'),'-d',str(ROOT/'work/tools'),str(ROOT/'work/tools/Patch.java')],check=True)
versions={'crafting':('WitherCrafting','1.2.1','me/withercrafting/WitherCrafting'),'bosses':('WitherBosses','1.5.8','me/witherbosses/WitherBosses'),'gens':('WitherGens','1.6.1','me/withergens/WitherGens'),'crates':('WitherCrates','1.1.1','me/withercrates/WitherCrates'),'mobs':('WitherMobs','1.6.2','me/withermobs/WitherMobs')}
new={'npcs':('WitherNPCs','1.1.0','me.withernpcs.WitherNPCs','npc','[WitherRanks, WitherCrafting, WitherBosses]'), 'sidebar':('WitherSidebar','1.1.0','me.withersidebar.WitherSidebar','sidebar','[WitherRanks]'),'tab':('WitherTab','1.1.0','me.withertab.WitherTab','withertab','[WitherRanks, WitherSidebar]'),'leaderboards':('WitherLeaderboards','1.1.0','me.witherleaderboards.WitherLeaderboards','leaderboard','[WitherSidebar, WitherRanks]')}
release=ROOT/'outputs/Witherrgens-Windows-Update';(release/'jars').mkdir(parents=True,exist_ok=True)
for module in [m for m in [*versions,*new] if not __import__("sys").argv[1:] or m in __import__("sys").argv[1:]]:
 classes=ROOT/'work/classes'/module
 assert classes.resolve().is_relative_to((ROOT/"work/classes").resolve())
 if classes.exists():shutil.rmtree(classes)
 classes.mkdir(parents=True)
 sources=list((ROOT/'work/src/common').rglob('*.java'))+list((ROOT/'work/src'/module).rglob('*.java'))
 cmd=[JAVAC,'-encoding','UTF-8','-cp',str(ROOT/'work/lib/*')+';'+str(ROOT/'work/original/*'),'-d',str(classes),*map(str,sources)]
 result=subprocess.run(cmd,capture_output=True,text=True)
 if result.returncode: print(result.stdout,result.stderr);raise SystemExit(result.returncode)
 if module in versions:
  name,version,main=versions[module];old=next((ROOT/'work/original').glob(name+'-*.jar'))
  text=zipfile.ZipFile(old).read('plugin.yml').decode().replace('\r','');text=re.sub(r'(?m)^version:.*$',"version: '"+version+"'",text)
  if module=='crafting':text += '\n  recipe:\n    description: View unlocked recipes; operators may unlock recipes\n'
  if module=='gens':text=text.replace('softdepend:', '# original-softdepend:');text+='\nsoftdepend: [WitherRanks, WitherSidebar]\n'
  if module=='mobs':text+='\nsoftdepend: [WitherBosses]\n'
  (classes/'plugin.yml').write_text(text,encoding='utf-8')
  subprocess.run([JAVA,'-cp',str(ROOT/'work/tools')+';'+str(ROOT/'work/lib/asm.jar'),'Patch',str(old),str(release/'jars'/f'{name}-{version}.jar'),str(classes),main,main.rsplit('/',1)[0]+'/StoryFeatures'],check=True)
 else:
  name,version,main,command,soft=new[module]
  text=f"name: {name}\nversion: '{version}'\nmain: {main}\napi-version: '26.3'\nsoftdepend: {soft}\ncommands:\n  {command}:\n    description: {name} settings\n"
  if module=='leaderboards':text+='    aliases: [lb, wleaderboard]\n';text+='depend: [WitherSidebar]\n'
  if module=='npcs':text+='    aliases: [wnpc]\n'
  (classes/'plugin.yml').write_text(text)
  with zipfile.ZipFile(release/'jars'/f'{name}-{version}.jar','w',zipfile.ZIP_DEFLATED) as jar:
   for f in classes.rglob('*'):
    if f.is_file():jar.write(f,f.relative_to(classes).as_posix())
 print(f'Built {name} {version}')
catalog=json.loads((ROOT/'work/original/plugins.json').read_text())
for file in (release/'jars').glob('*.jar'):
 if file.name in ['WitherMobs-1.6.0.jar','WitherNPCs-1.0.0.jar']:continue
 name,version=file.stem.rsplit('-',1);entry={'name':name,'version':version,'file':'jars/'+file.name,'sha256':hashlib.sha256(file.read_bytes()).hexdigest()}
 index=next((i for i,x in enumerate(catalog['plugins']) if x['name']==name),None)
 if index is None:catalog['plugins'].append(entry)
 else:catalog['plugins'][index]=entry
(release/'plugins.json').write_text(json.dumps(catalog,indent=2)+'\n')
print('Catalog:',len(catalog['plugins']),'plugins')

from pathlib import Path
import json,hashlib,subprocess,zipfile
root=Path('outputs/Witherrgens-English-Update')
versions={'WitherBosses':'1.5.10','WitherCrafting':'1.2.3','WitherCrates':'1.1.3','WitherGens':'1.7.2','WitherItems':'1.14.3','WitherLeaderboards':'1.1.2','WitherMobs':'1.6.4','WitherNPCs':'1.1.2','WitherProgress':'1.1.1','WitherRanks':'1.2.2','WitherShops':'1.2.3','WitherSidebar':'1.1.2','WitherTab':'1.1.2'}
catalog=json.loads(Path('outputs/Witherrgens-Milestone-Update/plugins.json').read_text());changed=[]
for name,version in versions.items():
 source=next(Path('work/latest-2').glob(name+'-*.jar'));target=root/'jars'/f'{name}-{version}.jar'
 subprocess.run(['C:/Program Files/Java/jdk-25.0.3/bin/java.exe','-cp','work/menu-polish;work/lib/asm.jar','PolishPatch',str(source),str(target),'work/menu-polish/classes',version],check=True)
 entry=next(e for e in catalog['plugins'] if e['name']==name);entry.update(version=version,file='jars/'+target.name,sha256=hashlib.sha256(target.read_bytes()).hexdigest());changed.append(entry)
(root/'plugins.json').write_text(json.dumps(catalog,indent=2)+'\n',encoding='utf-8');Path('work/english-update/changed.json').write_text(json.dumps(changed,indent=2),encoding='utf-8')
(root/'README.txt').write_text('Witherrgens English language update\n\nAll built-in menu labels, reward descriptions, command descriptions, notifications and error messages introduced by the milestone update now use English. Saved copies of the previous default milestone title/chat notification are migrated to English on startup.\n\nLanguage preference: always use English for plugin content, documentation and assistant replies.\n\nNo in-game tests are performed.\n',encoding='utf-8')
with zipfile.ZipFile(root/'EnglishUpdate-Source.zip','w',zipfile.ZIP_DEFLATED) as z:
 for f in Path('work/menu-polish/src').rglob('*.java'):z.write(f,f.as_posix())
 for f in [Path('work/menu-polish/PolishPatch.java'),Path('work/english-update/build.py'),Path('work/english-update/translations.json'),Path('AGENTS.md')]:z.write(f,f.as_posix())
 z.write(root/'README.txt','README.txt')

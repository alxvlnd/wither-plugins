package me.witherprogress;



import java.util.*;

import java.time.Duration;

import org.bukkit.*;

import org.bukkit.entity.Player;

import org.bukkit.inventory.ItemStack;

import org.bukkit.configuration.ConfigurationSection;

import org.bukkit.configuration.file.YamlConfiguration;

import org.bukkit.plugin.Plugin;

import net.kyori.adventure.text.Component;

import net.kyori.adventure.title.Title;

import net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer;

import me.witherpolish.MenuLabels;



/** Presentation and automatic, persistent milestone reward delivery. */

public final class ProgressUpgrade {

 private static final Set<UUID> checking=new HashSet<>();

 private static final Set<UUID> scheduled=new HashSet<>();

 private static final Map<UUID,Deque<Runnable>> notices=new HashMap<>();

 private static final Map<UUID,Long> nextNotice=new HashMap<>();

 private static int clock;

 public static void install(Progress p){if(!p.isEnabled())return;EnglishDefaults.migrate(p);

  Bukkit.getScheduler().runTaskTimer(p,()->{

   for(Player player:Bukkit.getOnlinePlayers()){

    try{check(p.goals,player);}catch(Exception ex){p.getLogger().warning("Milestone check: "+ex.getMessage());}

    if(System.currentTimeMillis()>=nextNotice.getOrDefault(player.getUniqueId(),0L)){var queue=notices.get(player.getUniqueId());if(queue!=null&&!queue.isEmpty())queue.poll().run();if(queue!=null&&queue.isEmpty()){notices.remove(player.getUniqueId());nextNotice.remove(player.getUniqueId());}}

   }

   notices.keySet().removeIf(id->Bukkit.getPlayer(id)==null);clock++;

  },20L,20L);

  p.getLogger().info("Milestone auto rewards and announcement settings enabled.");

 }

 public static void hint(Goals g,Player player){UUID id=player.getUniqueId();if(!scheduled.add(id))return;Bukkit.getScheduler().runTask(g.p,()->{scheduled.remove(id);if(player.isOnline())check(g,player);});}

 private static void check(Goals g,Player player){

  if(!checking.add(player.getUniqueId()))return;

  try{Store data=g.p.data(player);if(data.blocked()||!player.getItemOnCursor().getType().isAir())return;

   for(String id:Progress.keys(g.defs,"goals"))if(!data.y.getBoolean("claimed."+id)&&g.complete(player,id)){claim(g,player,id);break;}

  }finally{checking.remove(player.getUniqueId());}

 }

 private static String plain(Component c){return c==null?"":PlainTextComponentSerializer.plainText().serialize(c);}

 static String itemName(ItemStack i){return i==null?"Invalid item":i.getAmount()+" × "+(i.hasItemMeta()&&i.getItemMeta().hasDisplayName()?plain(i.getItemMeta().displayName()):MenuLabels.pretty(i.getType().name().toLowerCase(Locale.ROOT)));}

 private static String name(Goals g,String id){if(g.defs.y.contains(g.path(id)+"name"))return g.defs.y.getString(g.path(id)+"name",id);try{return itemName(g.p.template(id).asOne());}catch(Exception ex){}return MenuLabels.pretty(id);}

 private static String unlockName(String type,String id){

  if(type.equals("RECIPE")){Plugin plugin=Bukkit.getPluginManager().getPlugin("WitherCrafting");if(plugin!=null)try{Object store=Bridge.field(plugin,"store");Object recipe=((Map<?,?>)Bridge.field(store,"recipes")).get(id);if(recipe!=null)return Objects.toString(Bridge.invoke(recipe,"name"),MenuLabels.pretty(id));}catch(Exception ignored){}}

  return MenuLabels.pretty(id);

 }

 private static String commandName(String command){String[] a=command.split(" +");if(a.length>=3&&a[0].equals("recipe")&&a[1].equals("unlock"))return "Unlock recipe: "+unlockName("RECIPE",a[2]);if(a.length>=3&&a[0].equals("portal")&&a[1].equals("unlock"))return "Unlock portal: "+unlockName("PORTAL",a[2]);if(a.length>=3&&a[0].equals("give"))return "Give item: "+a[2];if(command.equals("progress"))return "Open progress menu";return "Command: /"+command;}

 private static String label(Goals g,String path,boolean reward){

  String custom=g.defs.y.getString(path+"name","");if(!custom.isBlank())return custom;

  String type=g.defs.y.getString(path+"type","");String source=g.defs.y.getString(path+(reward?"value":"source"),"");long n=g.defs.y.getLong(path+"amount",1);

  return switch(type){

   case "ITEM" -> itemName(Store.item(source));case "COMMAND" -> commandName(source);

   case "RECIPE" -> "Unlock recipe: "+unlockName(type,source);case "PORTAL" -> "Unlock portal: "+unlockName(type,source);

   case "GEN" -> n+" blocks to mine in: "+name(g,source);case "MOB" -> n+" area mobs to defeat in: "+name(g,source);

   case "TYPE" -> n+" × "+name(g,source)+" to defeat";case "CRAFT" -> n+" × "+name(g,source)+" to craft";

   case "POSSESS" -> n+" × "+name(g,source)+" to possess";case "TURN_IN" -> n+" × "+name(g,source)+" to turn in";

   case "MILESTONE" -> "Complete milestone: "+name(g,source);case "QUEST" -> "Quest: "+name(g,source)+" · Stage "+n;

   case "CRATE_PREVIEW" -> "Open a crate preview";case "TALK" -> "Talk to the guide";default -> "Setting: "+type;

  };

 }

 private static Material icon(Goals g,String path){String type=g.defs.y.getString(path+"type","");return switch(type){case "GEN"->Material.IRON_PICKAXE;case "MOB","TYPE"->Material.ZOMBIE_SPAWN_EGG;case "CRAFT","RECIPE"->Material.CRAFTING_TABLE;case "POSSESS","ITEM"->Material.CHEST;case "TURN_IN"->Material.HOPPER;case "MILESTONE"->Material.NETHER_STAR;case "QUEST"->Material.WRITABLE_BOOK;case "CRATE_PREVIEW"->Material.ENDER_CHEST;case "TALK"->Material.VILLAGER_SPAWN_EGG;case "PORTAL"->Material.OBSIDIAN;case "COMMAND"->Material.COMMAND_BLOCK;default->Material.COMPARATOR;};}

 public static void entries(Goals g,Player player,String goal,boolean rewards){entries(g,player,goal,rewards,0);}

 private static void entries(Goals g,Player player,String goal,boolean rewards,int page){

  String root=g.path(goal)+(rewards?"rewards":"conditions");List<String> ids=new ArrayList<>(Progress.keys(g.defs,root));Ui.Menu m=new Ui.Menu(player,rewards?"Rewards":"Requirements",true);

  for(int i=page*45;i<Math.min(ids.size(),page*45+45);i++){String id=ids.get(i),path=root+"."+id+".";

   m.button(i%45,icon(g,path),label(g,path,rewards),e->entry(g,player,goal,path,rewards,page),"Click to edit or remove");

  }

  m.button(48,Material.EMERALD,"Add new",e->{if(rewards)addReward(g,player,goal);else g.chooseCondition(player,goal);});

  m.button(49,Material.ARROW,"Back",e->edit(g,player,goal));

  if(page>0)m.button(45,Material.ARROW,"Previous page",e->entries(g,player,goal,rewards,page-1));

  if((page+1)*45<ids.size())m.button(53,Material.ARROW,"Next page",e->entries(g,player,goal,rewards,page+1));m.open(player);

 }

 private static void entry(Goals g,Player p,String goal,String path,boolean reward,int page){

  Ui.Menu m=new Ui.Menu(p,label(g,path,reward),true);Runnable back=()->entries(g,p,goal,reward,page);

  m.button(10,Material.NAME_TAG,"Display name",e->Forms.show(g.p,p,"Display name","Leave blank to use the automatic description.",List.of(Forms.text("name","Name",g.defs.y.getString(path+"name",""),100)),v->{g.defs.y.set(path+"name",v.get("name"));g.defs.save();back.run();},back));

  String type=g.defs.y.getString(path+"type","");

  if(type.equals("COMMAND"))m.button(12,Material.COMMAND_BLOCK,"Edit command",e->commandForm(g,p,goal,path,back));

  if(!reward)m.button(12,Material.HOPPER,"Edit amount / stage",e->Forms.show(g.p,p,"Requirement","All requirements must be met.",List.of(Forms.text("amount","Amount / stage",Long.toString(g.defs.y.getLong(path+"amount",1)),10)),v->{long n=Long.parseLong(v.get("amount"));if(n<1||n>1000000000)throw new IllegalArgumentException("Amount: 1–1000000000");g.defs.y.set(path+"amount",n);g.defs.save();back.run();},back));

  if(reward&&(type.equals("RECIPE")||type.equals("PORTAL")))m.button(12,icon(g,path),"Change unlock",e->chooseUnlock(g,p,goal,type,path,back));

  m.button(16,Material.BARRIER,"Remove entry",e->Forms.confirm(g.p,p,"Remove entry?",label(g,path,reward),()->{g.defs.y.set(path.substring(0,path.length()-1),null);g.defs.save();back.run();},back));

  m.button(49,Material.ARROW,"Back",e->back.run());m.open(p);

 }

 public static void edit(Goals g,Player p,String goal){

  String path=g.path(goal);Ui.Menu m=new Ui.Menu(p,"Milestone: "+name(g,goal),true);

  m.button(10,Material.NAME_TAG,"Name, category and activation",e->Forms.show(g.p,p,"Milestone settings","Add at least one requirement, then enable the milestone.",List.of(Forms.text("name","Name",g.defs.y.getString(path+"name",goal),100),Forms.choice("category","Category",g.defs.y.getString(path+"category","milestones"),"mining","mobs","areas","milestones","intro"),Forms.choice("enabled","Enabled",g.defs.y.getBoolean(path+"enabled")?"yes":"no","yes","no")),v->{if(v.get("enabled").equals("yes")&&Progress.keys(g.defs,path+"conditions").isEmpty())throw new IllegalArgumentException("Add a requirement first.");g.defs.y.set(path+"name",v.get("name"));g.defs.y.set(path+"category",v.get("category"));g.defs.y.set(path+"enabled",v.get("enabled").equals("yes"));g.defs.save();edit(g,p,goal);},()->edit(g,p,goal)));

  m.button(12,Material.IRON_PICKAXE,"Requirements",e->entries(g,p,goal,false));m.button(14,Material.CHEST,"Rewards",e->entries(g,p,goal,true));

  m.button(16,Material.SPYGLASS,"Preview as player",e->view(g,p,goal,()->edit(g,p,goal)));

  m.button(28,Material.FIREWORK_ROCKET,"Title and chat messages",e->announcement(g,p,goal));

  m.button(30,Material.NOTE_BLOCK,"Achievement sound and duration",e->soundSettings(g,p,goal));

  m.button(32,Material.REPEATER,"Pending unlocks",e->pending(g,p));m.button(49,Material.ARROW,"Back",e->g.admin(p));m.open(p);

 }

 public static void view(Goals g,Player p,String goal,Runnable back){

  Ui.Menu m=new Ui.Menu(p,name(g,goal),false);String root=g.path(goal);int slot=0;

  for(String id:Progress.keys(g.defs,root+"conditions")){String path=root+"conditions."+id+".";if(slot>=36)break;m.button(slot++,icon(g,path),label(g,path,false),e->{String type=g.defs.y.getString(path+"type","");if(Set.of("CRAFT","POSSESS","TURN_IN").contains(type))g.recipe(p,g.defs.y.getString(path+"source",""),back);},g.description(p,path));}

  slot=36;for(String id:Progress.keys(g.defs,root+"rewards")){if(slot>=45)break;String path=root+"rewards."+id+".";m.button(slot++,icon(g,path),label(g,path,true),e->{},"Reward for this milestone");}

  boolean claimed=g.p.data(p).y.getBoolean("claimed."+goal);

  m.button(48,claimed?Material.LIME_DYE:Material.CLOCK,claimed?"Completed":"Completes automatically",e->{if(!claimed&&g.complete(p,goal))claim(g,p,goal);view(g,p,goal,back);},"Items that do not fit in your inventory are stored in /rewards.");m.button(49,Material.ARROW,"Back",e->back.run());m.open(p);

 }

 private static void announcement(Goals g,Player p,String goal){String path=g.path(goal)+"announcement.";

  Forms.show(g.p,p,"Milestone: title and chat","Placeholders: {player}, {milestone}, {rewards}, {pending}. MiniMessage colors and gradients are supported.",List.of(Forms.choice("show","Show title notification",g.defs.y.getBoolean(path+"show",true)?"yes":"no","yes","no"),Forms.text("title","Title",g.defs.y.getString(path+"title","<gold>Milestone reached!</gold>"),250),Forms.text("subtitle","Subtitle",g.defs.y.getString(path+"subtitle","<yellow>{milestone}</yellow>"),250),Forms.multiline("chat","Chat message (blank = disabled)",g.defs.y.getString(path+"chat","<green>Milestone: {milestone}</green>\n<gray>Rewards: {rewards}</gray>\n<yellow>{pending}</yellow>"),1500)),v->{g.defs.y.set(path+"show",v.get("show").equals("yes"));for(String key:List.of("title","subtitle","chat"))g.defs.y.set(path+key,v.get(key));g.defs.save();edit(g,p,goal);},()->edit(g,p,goal));

 }

 private static void soundSettings(Goals g,Player p,String goal){String path=g.path(goal)+"announcement.";

  Forms.show(g.p,p,"Sound and display duration","The default is the Minecraft achievement sound.",List.of(Forms.choice("sound","Sound",g.defs.y.getString(path+"sound","achievement"),"achievement","challenge","levelup","none"),Forms.text("seconds","Display duration (1–15 seconds)",g.defs.y.getString(path+"seconds","3"),2)),v->{int n=Integer.parseInt(v.get("seconds"));if(n<1||n>15)throw new IllegalArgumentException("Duration: 1–15 seconds");g.defs.y.set(path+"sound",v.get("sound"));g.defs.y.set(path+"seconds",n);g.defs.save();edit(g,p,goal);},()->edit(g,p,goal));

 }

 public static void addReward(Goals g,Player p,String goal){Ui.Menu m=new Ui.Menu(p,"Add reward",true);Runnable back=()->entries(g,p,goal,true);

  m.button(10,Material.CHEST,"Item from main hand",e->{ItemStack i=p.getInventory().getItemInMainHand();if(i.getType().isAir())throw new IllegalArgumentException("Hold the reward item in your main hand first.");g.addReward(goal,"ITEM",Store.item(i));back.run();},"Copies the item, amount and custom data.");

  m.button(12,Material.KNOWLEDGE_BOOK,"Unlock recipe",e->chooseUnlock(g,p,goal,"RECIPE",null,back));m.button(14,Material.OBSIDIAN,"Unlock portal",e->chooseUnlock(g,p,goal,"PORTAL",null,back));m.button(16,Material.COMMAND_BLOCK,"Console command",e->commandForm(g,p,goal,null,back));m.button(49,Material.ARROW,"Back",e->back.run());m.open(p);

 }

 private static void chooseUnlock(Goals g,Player p,String goal,String type,String path,Runnable back){

  List<String> ids=type.equals("RECIPE")?Bridge.keys(Bukkit.getPluginManager().getPlugin("WitherCrafting"),"store","recipes"):g.portals();

  if(ids.isEmpty())throw new IllegalArgumentException(type.equals("RECIPE")?"Create a custom recipe first.":"Create a portal first.");

  chooseUnlockPage(g,p,goal,type,path,back,ids,0);

 }

 private static void validateUnlock(String type,String id){
  if(type.equals("RECIPE")){Plugin plugin=Bukkit.getPluginManager().getPlugin("WitherCrafting");Object recipe=((Map<?,?>)Bridge.field(Bridge.field(plugin,"store"),"recipes")).get(id);if(recipe==null||!Boolean.TRUE.equals(Bridge.invoke(recipe,"enabled")))throw new IllegalArgumentException("This recipe is disabled. Enable it in the recipe editor first.");}
 }
 private static void chooseUnlockPage(Goals g,Player p,String goal,String type,String path,Runnable back,List<String> ids,int page){Ui.Menu m=new Ui.Menu(p,type.equals("RECIPE")?"Choose recipe":"Choose portal",true);

  for(int i=page*45;i<Math.min(ids.size(),page*45+45);i++){String id=ids.get(i);m.button(i%45,type.equals("RECIPE")?Material.KNOWLEDGE_BOOK:Material.OBSIDIAN,unlockName(type,id),e->{validateUnlock(type,id);if(path==null)g.addReward(goal,type,id);else{g.defs.y.set(path+"value",id);g.defs.save();}back.run();},"ID: "+id);}

  if(page>0)m.button(45,Material.ARROW,"Previous page",e->chooseUnlockPage(g,p,goal,type,path,back,ids,page-1));if((page+1)*45<ids.size())m.button(53,Material.ARROW,"Next page",e->chooseUnlockPage(g,p,goal,type,path,back,ids,page+1));m.button(49,Material.ARROW,"Back",e->back.run());m.open(p);

 }

 private static void commandForm(Goals g,Player p,String goal,String path,Runnable back){

  Forms.show(g.p,p,"Console command reward","Runs once as console. {player} = player name; {uuid} = player UUID. For unlocks, select Recipe or Portal directly. A leading / is removed.",List.of(Forms.text("name","Display name (optional)",path==null?"":g.defs.y.getString(path+"name",""),100),Forms.text("command","Command",path==null?"":g.defs.y.getString(path+"value",""),500)),v->{String cmd=v.get("command").strip();if(cmd.startsWith("/"))cmd=cmd.substring(1);if(cmd.isBlank()||cmd.contains("\n")||cmd.contains("\r")||cmd.contains("|"))throw new IllegalArgumentException("Enter one valid command.");String dest=path==null?g.path(goal)+"rewards."+UUID.randomUUID()+".":path;g.defs.y.set(dest+"type","COMMAND");g.defs.y.set(dest+"value",cmd);g.defs.y.set(dest+"name",v.get("name"));g.defs.save();back.run();},back);

 }

 public static void claim(Goals g,Player p,String goal){Store data=g.p.data(p);String root=g.path(goal);

  if(data.y.getBoolean("claimed."+goal))return;if(!g.complete(p,goal))throw new IllegalArgumentException("Complete all requirements first.");

  ItemStack[] inventory=Store.copies(p);

  for(String id:Progress.keys(g.defs,root+"conditions")){String path=root+"conditions."+id+".";if(!g.defs.y.getString(path+"type","").equals("TURN_IN"))continue;String src=g.defs.y.getString(path+"source","");long remaining=g.defs.y.getLong(path+"amount",1);

   for(int i=0;i<36&&remaining>0;i++){if(!src.equals(g.p.registered(inventory[i])))continue;int n=(int)Math.min(remaining,inventory[i].getAmount());inventory[i].setAmount(inventory[i].getAmount()-n);remaining-=n;if(inventory[i].getAmount()==0)inventory[i]=null;}if(remaining>0)throw new IllegalArgumentException("The required items have changed.");

  }

  Map<String,String> inbox=new LinkedHashMap<>();List<String> rewards=new ArrayList<>();List<String> queued=new ArrayList<>();

  if(!data.y.getBoolean("rewarded."+goal))for(String id:Progress.keys(g.defs,root+"rewards")){String path=root+"rewards."+id+".";String type=g.defs.y.getString(path+"type","");String value=g.defs.y.getString(path+"value","");String token=Banks.safe("goal:"+goal+":"+id);rewards.add(label(g,path,true));

   if(type.equals("ITEM")){ItemStack item=Store.item(value);if(item==null)throw new IllegalArgumentException("Invalid reward item: "+id);int remainder=Store.insert(inventory,item,36);if(remainder>0){item.setAmount(remainder);inbox.put(token,Store.item(item));}}else queued.add(id);

  }

  data.transaction(p,inventory,()->{data.y.set("claimed."+goal,true);if(data.y.getBoolean("rewarded."+goal))return;data.y.set("rewarded."+goal,true);

   inbox.forEach((token,item)->{data.y.set("inbox."+token,item);data.y.set("receipts."+token,true);});

   for(String id:queued){String path=root+"rewards."+id+".",dest="outbox."+Banks.safe("goal:"+goal+":"+id)+".";data.y.set(dest+"type",g.defs.y.getString(path+"type"));data.y.set(dest+"value",g.defs.y.getString(path+"value"));}

  });

  deliver(g,p);boolean pending=queued.stream().anyMatch(id->data.y.contains("outbox."+Banks.safe("goal:"+goal+":"+id)));

  String info=(inbox.isEmpty()?"":"Inventory full: collect the remaining items with /rewards.")+(pending?" Unlock/command pending; an operator can review the delivery.":"");

  announce(g,p,goal,rewards,info.strip());

 }

 private static String replace(String text,Player p,String name,String rewards,String pending){return text.replace("{player}",p.getName()).replace("{milestone}",name).replace("{rewards}",rewards).replace("{pending}",pending);}

 private static void announce(Goals g,Player p,String goal,List<String> rewards,String pending){String path=g.path(goal)+"announcement.",name=name(g,goal),rewardText=rewards.isEmpty()?"No additional reward":String.join(", ",rewards);

  String title=replace(g.defs.y.getString(path+"title","<gold>Milestone reached!</gold>"),p,name,rewardText,pending),subtitle=replace(g.defs.y.getString(path+"subtitle","<yellow>{milestone}</yellow>"),p,name,rewardText,pending);

  String chat=replace(g.defs.y.getString(path+"chat","<green>Milestone: {milestone}</green>\n<gray>Rewards: {rewards}</gray>\n<yellow>{pending}</yellow>"),p,name,rewardText,pending);

  for(String line:chat.split("\n"))if(!plain(Ui.text(line)).isBlank())p.sendMessage(Ui.text(line));

  if(!pending.isBlank()&&!chat.contains(pending))p.sendMessage(Ui.text("<yellow>"+pending));

  boolean show=g.defs.y.getBoolean(path+"show",true);String sound=g.defs.y.getString(path+"sound","achievement");int seconds=Math.clamp(g.defs.y.getInt(path+"seconds",3),1,15);

  notices.computeIfAbsent(p.getUniqueId(),id->new ArrayDeque<>()).add(()->{nextNotice.put(p.getUniqueId(),System.currentTimeMillis()+(seconds+1L)*1000);if(show)p.showTitle(Title.title(Ui.text(title),Ui.text(subtitle),Title.Times.times(Duration.ofMillis(300),Duration.ofSeconds(seconds),Duration.ofMillis(500))));if(!sound.equals("none"))p.playSound(p.getLocation(),switch(sound){case "challenge"->Sound.UI_TOAST_CHALLENGE_COMPLETE;case "levelup"->Sound.ENTITY_PLAYER_LEVELUP;default->Sound.UI_TOAST_CHALLENGE_COMPLETE;},1f,1f);});

 }

 public static void deliver(Goals g,Player p){Store data=g.p.data(p);if(data.blocked())return;

  for(String token:List.copyOf(Progress.keys(data,"outbox"))){String path="outbox."+token+".",type=data.y.getString(path+"type",""),value=data.y.getString(path+"value","");

   if(data.y.getString(path+"state","").equals("uncertain"))continue;
   // Legacy unlock commands are handled through the same verified grant API.
   if(type.equals("COMMAND")){
    String command=value.strip();if(command.startsWith("/"))command=command.substring(1);
    String[] parts=command.replace("{player}",p.getName()).split(" +");
    if((parts.length==3||parts.length==4)&&parts[1].equalsIgnoreCase("unlock")&&(parts.length==3||parts[3].equalsIgnoreCase(p.getName()))&&(parts[0].equalsIgnoreCase("recipe")||parts[0].equalsIgnoreCase("portal"))){type=parts[0].equalsIgnoreCase("recipe")?"RECIPE":"PORTAL";value=parts[2];data.y.set(path+"type",type);data.y.set(path+"value",value);data.save();}
   }


   try{

    if(type.equals("COMMAND")){

     // Once dispatched, arbitrary commands cannot safely be repeated after a crash.

     data.y.set(path+"state","uncertain");data.save();

     if(!Bukkit.dispatchCommand(Bukkit.getConsoleSender(),value.replace("{player}",p.getName()).replace("{uuid}",p.getUniqueId().toString())))throw new IllegalArgumentException("Command failed: /"+value);

    }else if(type.equals("RECIPE")){

     Plugin plugin=Bukkit.getPluginManager().getPlugin("WitherCrafting");if(plugin==null||!plugin.isEnabled())continue;Object store=Bridge.field(plugin,"store");if(!((Map<?,?>)Bridge.field(store,"recipes")).containsKey(value))throw new IllegalArgumentException("Recipe not found: "+value);

     Bridge.invoke(store,"unlock",p.getUniqueId(),value,true);

     if(!Boolean.TRUE.equals(Bridge.invoke(store,"unlocked",p.getUniqueId(),value)))throw new IllegalStateException("Recipe unlock was not saved.");

     // UI refresh must not block an already persisted unlock.

     try{Bridge.invoke(Bridge.field(plugin,"engine"),"syncAll");Bridge.invoke(plugin,"refreshViews");}catch(Exception ex){plugin.getLogger().warning("Recipe unlocked; UI refresh deferred: "+ex.getMessage());}

    }else if(type.equals("PORTAL")){

     Plugin plugin=Bukkit.getPluginManager().getPlugin("WitherGens");if(plugin==null||!plugin.isEnabled())continue;Object executor=((org.bukkit.plugin.java.JavaPlugin)plugin).getCommand("portal").getExecutor();

     Object map=Bridge.field(executor,"portals");if(!(map instanceof Map<?,?> portals)||!portals.containsKey(value))throw new IllegalArgumentException("Portal not found: "+value);

     Bridge.invoke(executor,"unlock",p,value,true);YamlConfiguration config=(YamlConfiguration)Bridge.field(executor,"data");if(!config.getBoolean("unlocks."+p.getUniqueId()+"."+value))throw new IllegalStateException("Portal unlock was not saved.");

    }else throw new IllegalArgumentException("Unknown reward type: "+type);

    boolean retried=data.y.contains(path+"error");data.y.set("outbox."+token,null);data.save();if(retried)p.sendMessage(Ui.text("<green>Reward delivered: "+(type.equals("COMMAND")?commandName(value):unlockName(type,value))+"</green>"));

   }catch(Exception ex){String message=Objects.toString(ex.getMessage(),"Delivery failed");String previous=data.y.getString(path+"error","");data.y.set(path+"error",message);data.save();if(!message.equals(previous))g.p.getLogger().warning("Reward retained for "+p.getName()+": "+message);}

  }

 }



 public static ItemStack decorate(ItemStack item){

  if(item==null||!item.hasItemMeta()||!item.getItemMeta().hasDisplayName())return item;

  try{

   Plugin plugin=Bukkit.getPluginManager().getPlugin("WitherProgress");if(!(plugin instanceof Progress p)||p.goals==null)return item;

   Goals g=p.goals;var meta=item.getItemMeta();String key=plain(meta.displayName());String display=null;Material material=item.getType();

   if(Progress.keys(g.defs,"goals").contains(key)){display=name(g,key);material=Material.NETHER_STAR;}

   else if(Progress.keys(p.settings,"items").contains(key)){ItemStack template=p.template(key);display=itemName(template.asOne());material=template.getType();}

   else if(key.matches("[a-fA-F0-9]{8}-[a-fA-F0-9-]{27}")){

    outer:for(String goal:Progress.keys(g.defs,"goals"))for(String group:List.of("conditions","rewards")){String path=g.path(goal)+group+"."+key+".";if(g.defs.y.contains(path+"type")){display=label(g,path,group.equals("rewards"));material=icon(g,path);break outer;}}

    if(display==null){Object loot=p.loot;Store io=(Store)Bridge.field(loot,"io");for(String path:io.y.getKeys(true))if(path.endsWith("."+key+".item")){ItemStack reward=Store.item(io.y.getString(path));display=itemName(reward)+" · "+io.y.getDouble(path.substring(0,path.length()-4)+"chance",100)+" %";if(reward!=null)material=reward.getType();break;}}

    if(display==null){Plugin equipment=Bukkit.getPluginManager().getPlugin("WitherEquipment");if(equipment!=null)try{Store io=(Store)Bridge.field(equipment,"io");for(String path:io.y.getKeys(true))if(path.endsWith("."+key+".type")){String root=path.substring(0,path.length()-4);display=MenuLabels.pretty(io.y.getString(path,"Effect"))+" · "+io.y.getDouble(root+"value")+" · "+io.y.getDouble(root+"chance",100)+" %";material=Material.BLAZE_POWDER;break;}}catch(Exception ignored){}}

    if(display==null){display="Reward / setting";material=Material.COMPARATOR;}

   }

   if(display!=null){List<Component> lore=meta.lore()==null?new ArrayList<>():new ArrayList<>(meta.lore());lore.add(Component.text("ID: "+key));meta.displayName(Ui.text("<italic:false>"+display));meta.lore(lore);item=item.withType(material);item.setItemMeta(meta);}

  }catch(Exception ignored){}return item;

 }

 private static void pending(Goals g,Player p){List<String> rows=new ArrayList<>();Map<String,String> pendingTokens=new HashMap<>();Map<String,Player> owners=new HashMap<>();for(Player target:Bukkit.getOnlinePlayers())for(String token:Progress.keys(g.p.data(target),"outbox")){String path="outbox."+token+".";String row=target.getName()+" · "+g.p.data(target).y.getString(path+"type","")+" · "+(rows.size()+1);rows.add(row);owners.put(row,target);pendingTokens.put(row,token);}

  Ui.list(p,"Pending rewards",rows,0,row->{Player target=owners.get(row);String token=pendingTokens.get(row),path="outbox."+token+".";Store data=g.p.data(target);Forms.confirm(g.p,p,"Retry delivery?",data.y.getString(path+"type","")+": "+data.y.getString(path+"value","")+"\n"+data.y.getString(path+"error","")+"\nWarning: console commands may already have run. Review the previous result before retrying.",()->{data.y.set(path+"state",null);data.save();deliver(g,target);pending(g,p);},()->pending(g,p));},()->g.admin(p));

 }

}


package me.witherprogress;
/** Upgrade only the previously shipped announcement defaults. */
public final class EnglishDefaults {
 public static void migrate(Progress p){
  boolean changed=false;
  for(String goal:Progress.keys(p.goals.defs,"goals")){
   String root="goals."+goal+".announcement.";
   for(String key:java.util.List.of("title","subtitle","chat")){
    String old=p.goals.defs.y.getString(root+key);if(old==null)continue;
    String translated=old.replace("Milestone erreicht!","Milestone reached!").replace("Belohnung: {rewards}","Rewards: {rewards}");
    if(!translated.equals(old)){p.goals.defs.y.set(root+key,translated);changed=true;}
   }
  }
  if(changed)p.goals.defs.save();
 }
}

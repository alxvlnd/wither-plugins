/*
 * Decompiled with CFR 0.152.
 * 
 * Could not load the following classes:
 *  org.bukkit.Bukkit
 *  org.bukkit.entity.Player
 *  org.bukkit.inventory.ItemStack
 *  org.bukkit.plugin.Plugin
 */
package me.witherprogress;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import me.witherprogress.Progress;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.Plugin;

public final class Bridge {
    public static Object field(Object object, String string) {
        for (Class<?> clazz = object.getClass(); clazz != null; clazz = clazz.getSuperclass()) {
            try {
                Field field = clazz.getDeclaredField(string);
                field.setAccessible(true);
                return field.get(object);
            }
            catch (NoSuchFieldException noSuchFieldException) {
                continue;
            }
            catch (Exception exception) {
                throw new IllegalStateException(exception);
            }
        }
        throw new IllegalArgumentException("Missing field: " + string);
    }

    public static Object invoke(Object target, String name, Object ... args) {
        for (Class<?> type=target.getClass();type!=null;type=type.getSuperclass()) {
            for (Method method:type.getDeclaredMethods()) {
                if(!method.getName().equals(name)||method.getParameterCount()!=args.length)continue;
                Class<?>[] params=method.getParameterTypes();boolean match=true;
                for(int i=0;i<params.length;i++){
                    Class<?> param=params[i];
                    if(param.isPrimitive())param=Map.of(boolean.class,Boolean.class,int.class,Integer.class,long.class,Long.class,double.class,Double.class,float.class,Float.class,short.class,Short.class,byte.class,Byte.class,char.class,Character.class).get(param);
                    if(args[i]==null?params[i].isPrimitive():!param.isInstance(args[i])){match=false;break;}
                }
                if(!match)continue;
                try{method.setAccessible(true);return method.invoke(target,args);}
                catch(java.lang.reflect.InvocationTargetException ex){throw new IllegalStateException(ex.getCause());}
                catch(Exception ex){throw new IllegalStateException(ex);}
            }
        }
        throw new IllegalArgumentException("Missing compatible method: "+name);
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public static Progress core() {
        Plugin plugin = Bukkit.getPluginManager().getPlugin("WitherProgress");
        if (!(plugin instanceof Progress)) return null;
        Progress progress = (Progress)plugin;
        if (!plugin.isEnabled()) return null;
        Progress progress2 = progress;
        return progress2;
    }

    public static void gen(Player player, Object object, boolean bl, ItemStack itemStack) {
        Progress progress = Bridge.core();
        if (progress != null) {
            progress.gen(player, Objects.toString(Bridge.field(object, "name")), bl, itemStack);
        }
    }

    public static void craft(Player player, ItemStack itemStack, int n) {
        Progress progress = Bridge.core();
        if (progress != null) {
            progress.crafted(player, itemStack, n);
        }
    }

    public static List<String> keys(Plugin plugin, String string, String string2) {
        if (plugin == null || !plugin.isEnabled()) {
            return List.of();
        }
        try {
            List<String> list;
            Object object = Bridge.field(plugin, string);
            Object object2 = Bridge.field(object, string2);
            if (object2 instanceof Map) {
                Map map = (Map)object2;
                list = map.keySet().stream().map(Object::toString).sorted().toList();
            } else {
                list = List.of();
            }
            return list;
        }
        catch (Exception exception) {
            return List.of();
        }
    }

    private Bridge() {
    }
}


import java.nio.file.*;import java.util.*;import java.util.jar.*;import org.objectweb.asm.*;
public class PolishPatch {
 static JarEntry entry(String name){JarEntry entry=new JarEntry(name);entry.setTime(0L);return entry;}
 static final String HELPER="me/witherprogress/ProgressUpgrade";
 static final String P="Lorg/bukkit/entity/Player;",S="Ljava/lang/String;",G="Lme/witherprogress/Goals;";
 static String replacement(String n,String d){return switch(n+d){
  case "checkHint("+P+")V"->"hint";case "deliver("+P+")V"->"deliver";
  case "claim("+P+S+")V"->"claim";case "edit("+P+S+")V"->"edit";
  case "entries("+P+S+"Z)V"->"entries";case "addReward("+P+S+")V"->"addReward";
  case "view("+P+S+"Ljava/lang/Runnable;)V"->"view";default->null;};}
 public static void main(String[] args)throws Exception{
  Path input=Path.of(args[0]),output=Path.of(args[1]),classes=Path.of(args[2]);String version=args[3];int[] changes={0};boolean progress=input.getFileName().toString().startsWith("WitherProgress-");
  try(JarFile jar=new JarFile(input.toFile());JarOutputStream out=new JarOutputStream(Files.newOutputStream(output))){
   for(var entry:Collections.list(jar.entries())){String name=entry.getName();if(name.startsWith("META-INF/")&&!name.equals("META-INF/MANIFEST.MF"))continue;if(progress&&name.equals("me/witherprogress/Bridge.class"))continue;
    byte[] bytes=jar.getInputStream(entry).readAllBytes();
    if(name.equals("plugin.yml")){String text=new String(bytes,java.nio.charset.StandardCharsets.UTF_8);text=text.replaceAll("(?m)^version:.*$","version: '"+version+"'");bytes=text.getBytes(java.nio.charset.StandardCharsets.UTF_8);}
    if(name.endsWith(".class")){
     ClassReader reader=new ClassReader(bytes);ClassWriter writer=new ClassWriter(reader,ClassWriter.COMPUTE_MAXS);
     reader.accept(new ClassVisitor(Opcodes.ASM9,writer){public MethodVisitor visitMethod(int access,String method,String desc,String sig,String[] exceptions){
      MethodVisitor mv=super.visitMethod(access,method,desc,sig,exceptions);
      String substitute=progress&&name.equals("me/witherprogress/Goals.class")?replacement(method,desc):null;
      if(substitute!=null){mv.visitCode();mv.visitVarInsn(Opcodes.ALOAD,0);int local=1;for(Type type:Type.getArgumentTypes(desc)){mv.visitVarInsn(type.getOpcode(Opcodes.ILOAD),local);local+=type.getSize();}mv.visitMethodInsn(Opcodes.INVOKESTATIC,HELPER,substitute,"("+G+desc.substring(1),false);mv.visitInsn(Opcodes.RETURN);mv.visitMaxs(0,0);mv.visitEnd();changes[0]++;return null;}
      boolean icon=(access&Opcodes.ACC_STATIC)!=0&&(method.equals("icon")||method.equals("button"))&&desc.startsWith("(Lorg/bukkit/Material;")&&desc.endsWith("Lorg/bukkit/inventory/ItemStack;");
      boolean start=progress&&name.equals("me/witherprogress/Progress.class")&&method.equals("onEnable");
      if(!icon&&!start)return mv;
      if(icon)changes[0]++;
      return new MethodVisitor(Opcodes.ASM9,mv){public void visitInsn(int op){if(icon&&op==Opcodes.ARETURN){super.visitMethodInsn(Opcodes.INVOKESTATIC,"me/witherpolish/MenuLabels","decorate","(Lorg/bukkit/inventory/ItemStack;)Lorg/bukkit/inventory/ItemStack;",false);if(progress)super.visitMethodInsn(Opcodes.INVOKESTATIC,HELPER,"decorate","(Lorg/bukkit/inventory/ItemStack;)Lorg/bukkit/inventory/ItemStack;",false);}if(start&&op==Opcodes.RETURN){super.visitVarInsn(Opcodes.ALOAD,0);super.visitMethodInsn(Opcodes.INVOKESTATIC,HELPER,"install","(Lme/witherprogress/Progress;)V",false);}super.visitInsn(op);}};
     }},0);bytes=writer.toByteArray();
    }
    out.putNextEntry(entry(name));out.write(bytes);out.closeEntry();
   }
   try(var paths=Files.walk(classes)){for(Path file:paths.filter(Files::isRegularFile).toList()){String name=classes.relativize(file).toString().replace('\\','/');if(!name.endsWith(".class")||(!name.startsWith("me/witherpolish/")&&!(progress&&name.startsWith("me/witherprogress/"))))continue;out.putNextEntry(entry(name));out.write(Files.readAllBytes(file));out.closeEntry();}}
  }
  System.out.println(input.getFileName()+" => "+output.getFileName()+" ("+changes[0]+" hooks)");
 }
}

Witherrgens English language update

All built-in menu labels, reward descriptions, command descriptions, notifications and error messages introduced by the milestone update now use English. Saved copies of the previous default milestone title/chat notification are migrated to English on startup.

Language preference: always use English for plugin content, documentation and assistant replies.

No in-game tests are performed.

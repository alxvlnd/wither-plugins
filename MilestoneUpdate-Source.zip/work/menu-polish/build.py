from pathlib import Path
import json,hashlib,subprocess
root=Path('outputs/Witherrgens-Milestone-Update');(root/'jars').mkdir(parents=True,exist_ok=True)
versions={'WitherBosses':'1.5.9','WitherCrafting':'1.2.2','WitherCrates':'1.1.2','WitherGens':'1.7.1','WitherItems':'1.14.2','WitherLeaderboards':'1.1.1','WitherMobs':'1.6.3','WitherNPCs':'1.1.1','WitherProgress':'1.1.0','WitherRanks':'1.2.1','WitherShops':'1.2.2','WitherSidebar':'1.1.1','WitherTab':'1.1.1'}
catalog=json.loads(Path('work/latest-2-catalog.json').read_text());changed=[]
for name,version in versions.items():
 source=next(Path('work/latest-2').glob(name+'-*.jar'));target=root/'jars'/f'{name}-{version}.jar'
 subprocess.run(['C:/Program Files/Java/jdk-25.0.3/bin/java.exe','-cp','work/menu-polish;work/lib/asm.jar','PolishPatch',str(source),str(target),'work/menu-polish/classes',version],check=True)
 entry=next(e for e in catalog['plugins'] if e['name']==name);entry.update(version=version,file='jars/'+target.name,sha256=hashlib.sha256(target.read_bytes()).hexdigest());changed.append(entry)
(root/'plugins.json').write_text(json.dumps(catalog,indent=2)+'\n',encoding='utf-8');Path('work/menu-polish/changed.json').write_text(json.dumps(changed,indent=2),encoding='utf-8')

package me.witherpolish;
import java.util.*;
import org.bukkit.*;
import org.bukkit.inventory.ItemStack;
import net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer;
public final class MenuLabels {
 public static String pretty(String s){return Arrays.stream(s.replace('_',' ').replace('-',' ').split(" +")).filter(x->!x.isEmpty()).map(x->Character.toUpperCase(x.charAt(0))+x.substring(1)).reduce((a,b)->a+" "+b).orElse(s);}
 public static Material material(String label,Material fallback){
  String s=label.toLowerCase(Locale.ROOT);
  String[][] rules={
   {"add new|create|add |neu|erstellen","EMERALD"},{"delete|remove|löschen|entfernen","BARRIER"},
   {"back|previous|next|zurück|weiter","ARROW"},{"command|befehl","COMMAND_BLOCK"},
   {"recipe|craft|rezept","CRAFTING_TABLE"},{"cooldown|delay|interval|time|dauer|zeit","CLOCK"},
   {"requirement|condition|voraussetzung","COMPARATOR"},{"reward|belohnung|loot|drop","CHEST"},
   {"milestone|fortschritt","NETHER_STAR"},{"mining|block|generator|gen area","IRON_PICKAXE"},
   {"mob|kill|damage|combat|schaden","IRON_SWORD"},{"portal|teleport|world|location|position","ENDER_PEARL"},
   {"storage|capacity|material|lager","BARREL"},{"vault","ENDER_CHEST"},{"rank|permission|rang","GOLDEN_HELMET"},
   {"name|title|titel","NAME_TAG"},{"text|dialog|line|header|footer|description","WRITABLE_BOOK"},
   {"color|gradient|farbe","MAGENTA_DYE"},{"texture|skin|model|appearance","PAINTING"},
   {"player|spieler|owner","PLAYER_HEAD"},{"enable|toggle|active|aktiv","LEVER"},
   {"health|heal|leben","GOLDEN_APPLE"},{"speed|movement","SUGAR"},{"chance|weight|random","SUNFLOWER"},
   {"amount|count|quantity|menge|limit","HOPPER"},{"price|cost|money|preis","GOLD_INGOT"},
   {"stat|leaderboard|score","GOLD_BLOCK"},{"equipment|armor","IRON_CHESTPLATE"},
   {"npc|guide|talk","VILLAGER_SPAWN_EGG"},{"quest|intro|story","WRITABLE_BOOK"},
   {"key|lock|unlock","TRIPWIRE_HOOK"},{"preview|inspect|view","SPYGLASS"},
   {"effect|prosperity|aftershock","BLAZE_POWDER"},{"setting|option|config|einstellung","COMPARATOR"},{"save|confirm|apply","LIME_DYE"},
   {"gen","IRON_PICKAXE"},{"type","ZOMBIE_SPAWN_EGG"},{"item|possess","CHEST"},{"turn_in","HOPPER"},{"areas","ENDER_PEARL"}
  };
  for(String[] rule:rules)for(String word:rule[0].split("\\|"))if(s.contains(word))return Material.valueOf(rule[1]);
  Material exact=Material.matchMaterial(label.toUpperCase(Locale.ROOT));if(exact!=null&&!exact.isAir()&&exact.isItem())return exact;
  return fallback==Material.PAPER?Material.COMPARATOR:fallback;
 }
 public static ItemStack decorate(ItemStack original){
  if(original==null||original.getType().isAir())return original;
  try{var meta=original.getItemMeta();if(meta==null||!meta.hasDisplayName()||meta.hasCustomModelData())return original;
   String label=PlainTextComponentSerializer.plainText().serialize(meta.displayName());
   
   if(original.getType()==Material.COMMAND_BLOCK&&label.matches("\\d+\\. .+")){
    String cmd=label.substring(label.indexOf(' ')+1);String[] a=cmd.split(" +");String display=null;
    if(a.length>=3&&a[0].equals("recipe")&&a[1].equals("unlock"))display="Rezept freischalten: "+pretty(a[2]);
    else if(a.length>=3&&a[0].equals("portal")&&a[1].equals("unlock"))display="Portal freischalten: "+pretty(a[2]);
    else if(cmd.equals("progress"))display="Fortschrittsmenü öffnen";
    if(display!=null){var lore=meta.lore()==null?new java.util.ArrayList<net.kyori.adventure.text.Component>():new java.util.ArrayList<>(meta.lore());lore.add(net.kyori.adventure.text.Component.text("Befehl: /"+cmd));meta.displayName(net.kyori.adventure.text.Component.text(display));meta.lore(lore);original.setItemMeta(meta);}
   }
   if(original.getType()!=Material.PAPER)return original;
   ItemStack result=original.withType(material(label,original.getType()));result.setItemMeta(meta);return result;
  }catch(Exception ignored){return original;}
 }
}

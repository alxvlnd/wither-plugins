package me.witherprogress;
import java.util.*;import java.nio.file.*;import java.lang.reflect.*;import org.bukkit.entity.Player;import org.bukkit.Material;import org.bukkit.inventory.ItemStack;import sun.misc.Unsafe;
public class UpgradeChecks{
 static Unsafe unsafe()throws Exception{Field f=Unsafe.class.getDeclaredField("theUnsafe");f.setAccessible(true);return(Unsafe)f.get(null);}
 static void field(Object o,String n,Object v)throws Exception{Field f=o.getClass().getDeclaredField(n);f.setAccessible(true);f.set(o,v);}
 static void ok(boolean b,String s){if(!b)throw new AssertionError(s);}
 static class Parent{private String test(String s){return "inherited:"+s;}}
 static class Overloads extends Parent{private String select(Integer i){return "int";}private String select(UUID id){return "uuid";}private boolean flag(boolean b){return b;}}
 static class Stack extends ItemStack{int amount;Material type;Stack(Material type,int amount){this.type=type;this.amount=amount;}public Material getType(){return type;}public int getAmount(){return amount;}public void setAmount(int n){amount=n;}public int getMaxStackSize(){return 64;}public boolean isSimilar(ItemStack s){return s!=null&&s.getType()==type;}public ItemStack clone(){return new Stack(type,amount);}}
 public static void main(String[]args)throws Exception{
  Overloads target=new Overloads();ok(Bridge.invoke(target,"select",UUID.randomUUID()).equals("uuid"),"overload UUID");ok(Bridge.invoke(target,"select",2).equals("int"),"overload Integer");ok(Bridge.invoke(target,"test","yes").equals("inherited:yes"),"inherited method");ok(Boolean.TRUE.equals(Bridge.invoke(target,"flag",true)),"primitive boolean");
  UUID uuid=UUID.randomUUID();Player player=(Player)Proxy.newProxyInstance(Player.class.getClassLoader(),new Class[]{Player.class},(o,m,a)->switch(m.getName()){case "getUniqueId"->uuid;case "getName"->"TestPlayer";default->m.getReturnType()==boolean.class?false:null;});
  Path dir=Files.createTempDirectory(Path.of("work/menu-polish"),"checks-");Store defs=new Store(dir.resolve("goals.yml")),data=new Store(dir.resolve("player.yml"));
  Progress p=(Progress)unsafe().allocateInstance(Progress.class);field(p,"players",new HashMap<>(Map.of(uuid,data)));Goals g=(Goals)unsafe().allocateInstance(Goals.class);field(g,"p",p);field(g,"defs",defs);
  String root="goals.test.";defs.y.set(root+"enabled",true);ok(!g.complete(player,"test"),"empty goal must not complete");defs.y.set(root+"conditions.a.type","GEN");defs.y.set(root+"conditions.a.source","stone");defs.y.set(root+"conditions.a.amount",64);data.y.set("stats.gens.stone",63);ok(!g.complete(player,"test"),"under threshold");data.y.set("stats.gens.stone",64);ok(g.complete(player,"test"),"exact threshold");defs.y.set(root+"conditions.b.type","MILESTONE");defs.y.set(root+"conditions.b.source","previous");defs.y.set(root+"conditions.b.amount",1);ok(!g.complete(player,"test"),"chain requirement");data.y.set("claimed.previous",true);ok(g.complete(player,"test"),"chain unlock");defs.y.set(root+"enabled",false);ok(!g.complete(player,"test"),"disabled must not complete");
  var replace=ProgressUpgrade.class.getDeclaredMethod("replace",String.class,Player.class,String.class,String.class,String.class);replace.setAccessible(true);ok(replace.invoke(null,"{player}/{milestone}/{rewards}/{pending}",player,"Goal","Reward","Inbox").equals("TestPlayer/Goal/Reward/Inbox"),"notification placeholders");
  System.out.println("PASS 11 reflection, completion thresholds, prerequisite chain, disabled goal and announcement checks; no server interaction.");
 }
}
